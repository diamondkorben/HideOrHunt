# gameapi
API for easily creating PocketMine games
## Usage
Since code says more than thousand words, check out games that use this API:
- [XBedWars by XenialDan](https://github.com/thebigsmileXD/BedWars)
- [Spleef by XenialDan](https://github.com/thebigsmileXD/Spleef) (Easy to understand for beginners)
- [TNTRun by XenialDan](https://github.com/thebigsmileXD/TNTRun) (Easy to understand for beginners)
- Write an issue with `[Example]` in the title or description to get your game added here